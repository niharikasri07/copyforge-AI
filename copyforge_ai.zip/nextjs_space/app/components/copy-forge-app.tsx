'use client';

import { useState, useRef, useCallback, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import {
  Zap,
  FileText,
  Search,
  Sparkles,
  ArrowRight,
  Copy,
  Check,
  Download,
  RefreshCw,
  Pencil,
  ChevronDown,
  ChevronUp,
  Layers,
  Target,
  ClipboardList,
  Menu,
  X,
} from 'lucide-react';

/* ───────── Types ───────── */
interface FormData {
  businessName: string;
  industry: string;
  description: string;
  targetAudience: string;
  productsServices: string;
  tone: string;
  seoKeywords: string;
  callToAction: string;
}

interface HomePageContent {
  headline?: string;
  subheadline?: string;
  introduction?: string;
  valuePropositions?: string[];
  callToAction?: string;
}
interface AboutPageContent {
  introduction?: string;
  mission?: string;
  values?: string;
  whatMakesUsDifferent?: string;
}
interface Service {
  name?: string;
  description?: string;
  benefits?: string[];
  callToAction?: string;
}
interface ServicesPageContent {
  intro?: string;
  services?: Service[];
}
interface FAQ {
  question?: string;
  answer?: string;
}
interface SEOContent {
  seoTitle?: string;
  metaDescription?: string;
  primaryKeyword?: string;
  secondaryKeywords?: string[];
  urlSlug?: string;
}
interface GeneratedContent {
  homePage?: HomePageContent;
  aboutPage?: AboutPageContent;
  servicesPage?: ServicesPageContent;
  faqs?: FAQ[];
  seoMetadata?: SEOContent;
}

type Tab = 'home' | 'about' | 'services' | 'faqs' | 'seo';

const TABS: { id: Tab; label: string; icon: any }[] = [
  { id: 'home', label: 'Home', icon: Sparkles },
  { id: 'about', label: 'About', icon: FileText },
  { id: 'services', label: 'Services', icon: Layers },
  { id: 'faqs', label: 'FAQs', icon: ClipboardList },
  { id: 'seo', label: 'SEO', icon: Search },
];

const TONES = ['Professional', 'Friendly', 'Persuasive', 'Minimal', 'Playful'];

const emptyForm: FormData = {
  businessName: '',
  industry: '',
  description: '',
  targetAudience: '',
  productsServices: '',
  tone: 'Professional',
  seoKeywords: '',
  callToAction: '',
};

/* ───────────── Component ───────────── */
export default function CopyForgeApp() {
  const [form, setForm] = useState<FormData>(emptyForm);
  const [errors, setErrors] = useState<Partial<Record<keyof FormData, string>>>({});
  const [loading, setLoading] = useState(false);
  const [loadingMsg, setLoadingMsg] = useState('');
  const [loadingStep, setLoadingStep] = useState(0);
  const [result, setResult] = useState<GeneratedContent | null>(null);
  const [activeTab, setActiveTab] = useState<Tab>('home');
  const [copied, setCopied] = useState<string | null>(null);
  const [editing, setEditing] = useState(false);
  const [openFaq, setOpenFaq] = useState<number | null>(null);
  const [mobileNav, setMobileNav] = useState(false);

  const formRef = useRef<HTMLDivElement>(null);
  const resultsRef = useRef<HTMLDivElement>(null);

  /* field change */
  const onChange = useCallback(
    (field: keyof FormData, value: string) => {
      setForm((prev) => ({ ...(prev ?? {}), [field]: value }));
      if (errors?.[field]) setErrors((prev) => ({ ...(prev ?? {}), [field]: undefined }));
    },
    [errors]
  );

  /* validate */
  const validate = (): boolean => {
    const e: Partial<Record<keyof FormData, string>> = {};
    if (!form?.businessName?.trim()) e.businessName = 'Business name is required';
    if (!form?.industry?.trim()) e.industry = 'Industry is required';
    if (!form?.description?.trim()) e.description = 'Description is required';
    if (!form?.targetAudience?.trim()) e.targetAudience = 'Target audience is required';
    if (!form?.productsServices?.trim()) e.productsServices = 'Products/services are required';
    if (!form?.tone?.trim()) e.tone = 'Please select a tone';
    setErrors(e);
    if (Object.keys(e ?? {}).length > 0) {
      const firstKey = Object.keys(e)[0];
      const el = document.getElementById(`field-${firstKey}`);
      el?.scrollIntoView?.({ behavior: 'smooth', block: 'center' });
      return false;
    }
    return true;
  };

  /* generate */
  const handleGenerate = async () => {
    if (!validate()) return;
    setLoading(true);
    setLoadingMsg('Connecting to AI...');
    setLoadingStep(0);
    setResult(null);

    try {
      const res = await fetch('/api/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(form),
      });

      if (!res.ok) throw new Error('Server error');

      const reader = res.body?.getReader();
      if (!reader) throw new Error('No response stream');
      const decoder = new TextDecoder();
      let partialRead = '';

      while (true) {
        const { done, value } = await reader.read();
        if (done) break;
        partialRead += decoder.decode(value, { stream: true });
        const lines = partialRead.split('\n');
        partialRead = lines.pop() ?? '';

        for (const line of lines) {
          if (line.startsWith('data: ')) {
            const data = line.slice(6);
            if (data === '[DONE]') break;
            try {
              const parsed = JSON.parse(data);
              if (parsed?.status === 'processing') {
                setLoadingMsg(parsed?.message ?? 'Generating...');
                setLoadingStep(parsed?.step ?? 0);
              } else if (parsed?.status === 'completed') {
                setResult(parsed?.result ?? null);
                setLoading(false);
                setActiveTab('home');
                setTimeout(() => {
                  resultsRef.current?.scrollIntoView?.({ behavior: 'smooth', block: 'start' });
                }, 200);
                return;
              } else if (parsed?.status === 'error') {
                throw new Error(parsed?.message ?? 'Generation failed');
              }
            } catch {
              // skip
            }
          }
        }
      }
      setLoading(false);
    } catch (err: any) {
      console.error(err);
      setLoading(false);
    }
  };

  /* copy helpers */
  const tabToText = (tab: Tab): string => {
    if (!result) return '';
    switch (tab) {
      case 'home': {
        const h = result?.homePage;
        return `HEADLINE: ${h?.headline ?? ''}\n\nSUBHEADLINE: ${h?.subheadline ?? ''}\n\nINTRODUCTION:\n${h?.introduction ?? ''}\n\nVALUE PROPOSITIONS:\n${(h?.valuePropositions ?? []).map((v: string, i: number) => `${i + 1}. ${v}`).join('\n')}\n\nCALL TO ACTION: ${h?.callToAction ?? ''}`;
      }
      case 'about': {
        const a = result?.aboutPage;
        return `INTRODUCTION:\n${a?.introduction ?? ''}\n\nMISSION:\n${a?.mission ?? ''}\n\nVALUES:\n${a?.values ?? ''}\n\nWHAT MAKES US DIFFERENT:\n${a?.whatMakesUsDifferent ?? ''}`;
      }
      case 'services': {
        const s = result?.servicesPage;
        let text = `INTRO: ${s?.intro ?? ''}\n\n`;
        (s?.services ?? []).forEach((svc: Service, i: number) => {
          text += `SERVICE ${i + 1}: ${svc?.name ?? ''}\n${svc?.description ?? ''}\nBenefits: ${(svc?.benefits ?? []).join(', ')}\nCTA: ${svc?.callToAction ?? ''}\n\n`;
        });
        return text;
      }
      case 'faqs': {
        return (result?.faqs ?? [])
          .map((f: FAQ, i: number) => `Q${i + 1}: ${f?.question ?? ''}\nA: ${f?.answer ?? ''}`)
          .join('\n\n');
      }
      case 'seo': {
        const m = result?.seoMetadata;
        return `SEO TITLE: ${m?.seoTitle ?? ''}\nMETA DESCRIPTION: ${m?.metaDescription ?? ''}\nPRIMARY KEYWORD: ${m?.primaryKeyword ?? ''}\nSECONDARY KEYWORDS: ${(m?.secondaryKeywords ?? []).join(', ')}\nURL SLUG: ${m?.urlSlug ?? ''}`;
      }
    }
  };

  const copyText = async (text: string, label: string) => {
    try {
      await navigator.clipboard?.writeText?.(text);
      setCopied(label);
      setTimeout(() => setCopied(null), 2000);
    } catch {
      console.error('Copy failed');
    }
  };

  const copyAll = () => {
    const all = TABS.map((t) => `=== ${t.label.toUpperCase()} PAGE ===\n\n${tabToText(t.id)}`).join('\n\n\n');
    copyText(all, 'all');
  };

  const downloadTxt = () => {
    const all = TABS.map((t) => `=== ${t.label.toUpperCase()} PAGE ===\n\n${tabToText(t.id)}`).join('\n\n\n');
    const blob = new Blob([all], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${form?.businessName?.replace?.(/\s+/g, '_') ?? 'website'}_copy.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const handleGenerateAgain = () => {
    setResult(null);
    formRef.current?.scrollIntoView?.({ behavior: 'smooth', block: 'center' });
  };

  /* Demo handler */
  const handleDemo = () => {
    setForm({
      businessName: 'GreenLeaf Café',
      industry: 'Restaurant / Café',
      description: 'A farm-to-table organic café serving locally sourced, seasonal dishes in a warm, community-focused atmosphere.',
      targetAudience: 'Health-conscious food lovers aged 25-45 who value sustainability and local sourcing',
      productsServices: 'Dine-in seasonal menu, catering and private events, weekly Farm Box subscription, artisanal coffee and pastries',
      tone: 'Friendly',
      seoKeywords: 'organic restaurant, farm-to-table, sustainable dining, local café',
      callToAction: 'Reserve Your Table',
    });
    formRef.current?.scrollIntoView?.({ behavior: 'smooth', block: 'center' });
  };

  /* smooth scroll */
  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView?.({ behavior: 'smooth' });
    setMobileNav(false);
  };

  /* Counter animation hook */
  const AnimatedCounter = ({ end, suffix = '' }: { end: number; suffix?: string }) => {
    const [count, setCount] = useState(0);
    const ref = useRef<HTMLSpanElement>(null);
    useEffect(() => {
      let start = 0;
      const duration = 1500;
      const step = (ts: number) => {
        if (!start) start = ts;
        const progress = Math.min((ts - start) / duration, 1);
        setCount(Math.floor(progress * end));
        if (progress < 1) requestAnimationFrame(step);
      };
      const timer = requestAnimationFrame(step);
      return () => cancelAnimationFrame(timer);
    }, [end]);
    return <span ref={ref}>{count}{suffix}</span>;
  };

  /* ──────────── RENDER ──────────── */
  return (
    <div className="relative overflow-hidden">
      {/* Floating orbs */}
      <div className="orb orb-1" />
      <div className="orb orb-2" />
      <div className="orb orb-3" />

      {/* ===== NAVBAR ===== */}
      <nav className="fixed top-0 left-0 right-0 z-50 glass border-b border-white/5">
        <div className="max-w-[1200px] mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <button onClick={() => scrollTo('hero')} className="flex items-center gap-2 group">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-violet-500 to-indigo-600 flex items-center justify-center shadow-lg">
              <Zap className="w-4 h-4 text-white" />
            </div>
            <span className="text-lg font-bold gradient-text">CopyForge AI</span>
          </button>

          <div className="hidden md:flex items-center gap-6">
            <button onClick={() => scrollTo('features')} className="text-sm text-gray-300 hover:text-white transition-colors">Features</button>
            <button onClick={() => scrollTo('how-it-works')} className="text-sm text-gray-300 hover:text-white transition-colors">How It Works</button>
            <button onClick={() => scrollTo('generate')} className="text-sm text-gray-300 hover:text-white transition-colors">Generate</button>
            <button
              onClick={() => scrollTo('generate')}
              className="btn-gradient px-5 py-2 rounded-full text-sm font-semibold text-white"
            >
              Try Now
            </button>
          </div>

          <button onClick={() => setMobileNav(!mobileNav)} className="md:hidden text-white">
            {mobileNav ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>

        {/* Mobile nav */}
        <AnimatePresence>
          {mobileNav && (
            <motion.div
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              className="md:hidden glass overflow-hidden"
            >
              <div className="px-6 py-4 flex flex-col gap-3">
                <button onClick={() => scrollTo('features')} className="text-gray-300 hover:text-white text-left">Features</button>
                <button onClick={() => scrollTo('how-it-works')} className="text-gray-300 hover:text-white text-left">How It Works</button>
                <button onClick={() => scrollTo('generate')} className="text-gray-300 hover:text-white text-left">Generate</button>
                <button onClick={() => scrollTo('generate')} className="btn-gradient px-5 py-2 rounded-full text-sm font-semibold text-white w-fit">Try Now</button>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </nav>

      {/* ===== HERO ===== */}
      <section id="hero" className="relative pt-32 pb-20 sm:pt-40 sm:pb-28 px-4">
        <div className="max-w-[1200px] mx-auto text-center">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.7 }}>
            <div className="inline-flex items-center gap-2 glass rounded-full px-4 py-1.5 text-xs text-violet-300 mb-6">
              <Sparkles className="w-3.5 h-3.5" /> AI-Powered Website Copy Generator
            </div>

            <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-extrabold tracking-tight leading-tight">
              <span className="gradient-text">Your Website Copy,</span>
              <br />
              <span className="text-white">Generated in Minutes.</span>
            </h1>

            <p className="mt-6 text-base sm:text-lg text-gray-400 max-w-2xl mx-auto leading-relaxed">
              Stop staring at a blank page. Tell us about your business and our AI writes compelling,
              SEO-optimized website copy for every page — <span className="text-violet-400 font-medium">instantly</span>.
            </p>

            <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-4">
              <button
                onClick={() => scrollTo('generate')}
                className="btn-gradient px-8 py-3.5 rounded-full text-base font-semibold text-white flex items-center gap-2"
              >
                Generate My Website Copy <ArrowRight className="w-4 h-4" />
              </button>
              <button
                onClick={handleDemo}
                className="px-8 py-3.5 rounded-full text-base font-semibold text-gray-300 border border-white/10 hover:border-white/25 hover:bg-white/5 transition-all"
              >
                See a Demo
              </button>
            </div>
          </motion.div>

          {/* Stats row */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.6 }}
            className="mt-16 grid grid-cols-3 gap-4 max-w-lg mx-auto"
          >
            {[
              { value: 500, suffix: '+', label: 'Businesses Helped' },
              { value: 5, suffix: '', label: 'Pages Generated' },
              { value: 30, suffix: 's', label: 'Average Time' },
            ].map((s, i) => (
              <div key={i} className="text-center">
                <div className="text-2xl sm:text-3xl font-bold text-white">
                  {i === 2 && '< '}
                  <AnimatedCounter end={s.value} suffix={s.suffix} />
                </div>
                <div className="text-xs text-gray-500 mt-1">{s.label}</div>
              </div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* ===== FEATURES ===== */}
      <section id="features" className="py-20 px-4">
        <div className="max-w-[1200px] mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-center mb-14"
          >
            <h2 className="text-3xl sm:text-4xl font-bold text-white">Why Choose <span className="gradient-text">CopyForge?</span></h2>
            <p className="text-gray-400 mt-3 max-w-lg mx-auto">Everything you need to create professional website copy, powered by cutting-edge AI.</p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-6">
            {[
              {
                icon: Sparkles,
                title: 'AI-Powered Generation',
                desc: 'Advanced language model crafts copy tailored to your brand voice, audience, and industry — rivaling top-tier human writers.',
              },
              {
                icon: FileText,
                title: '5 Complete Pages',
                desc: 'Home, About, Services, FAQs, and SEO metadata — all generated in a single click. No more starting from scratch.',
              },
              {
                icon: Search,
                title: 'SEO Optimized',
                desc: 'Built-in keyword strategy, meta descriptions, and URL slugs that help search engines find and rank your site.',
              },
            ].map((f, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.15, duration: 0.5 }}
                className="glass-strong rounded-2xl p-6 hover:shadow-[0_0_30px_rgba(124,58,237,0.15)] transition-all duration-300 group cursor-default"
              >
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-violet-500/20 to-indigo-500/20 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
                  <f.icon className="w-6 h-6 text-violet-400" />
                </div>
                <h3 className="text-lg font-semibold text-white mb-2">{f.title}</h3>
                <p className="text-sm text-gray-400 leading-relaxed">{f.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== HOW IT WORKS ===== */}
      <section id="how-it-works" className="py-20 px-4 relative">
        <div className="max-w-[1200px] mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
            className="text-center mb-14"
          >
            <h2 className="text-3xl sm:text-4xl font-bold text-white">How It <span className="gradient-text">Works</span></h2>
            <p className="text-gray-400 mt-3">Three simple steps to professional website copy.</p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-8">
            {[
              { step: '01', title: 'Fill in Your Details', desc: 'Enter your business name, industry, audience, and services. Tell us the tone you want.' },
              { step: '02', title: 'AI Generates Copy', desc: 'Our AI analyzes your inputs and crafts tailored copy for 5 complete website pages.' },
              { step: '03', title: 'Copy, Edit & Publish', desc: 'Review your copy, edit inline, then copy it directly into your website builder.' },
            ].map((s, i) => (
              <motion.div
                key={i}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.15, duration: 0.5 }}
                className="text-center"
              >
                <div className="text-5xl font-black gradient-text opacity-40 mb-3">{s.step}</div>
                <h3 className="text-lg font-semibold text-white mb-2">{s.title}</h3>
                <p className="text-sm text-gray-400">{s.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* ===== FORM SECTION ===== */}
      <section id="generate" className="py-20 px-4">
        <div ref={formRef} className="max-w-[800px] mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <div className="text-center mb-10">
              <h2 className="text-3xl sm:text-4xl font-bold text-white">Generate Your <span className="gradient-text">Website Copy</span></h2>
              <p className="text-gray-400 mt-3">Fill in your business details and let AI do the heavy lifting.</p>
            </div>

            <div className="glass-strong rounded-2xl p-6 sm:p-8">
              <div className="space-y-5">
                {/* Business Name */}
                <Field id="businessName" label="Business Name" required error={errors?.businessName}>
                  <input
                    id="field-businessName"
                    value={form?.businessName ?? ''}
                    onChange={(e: any) => onChange('businessName', e?.target?.value ?? '')}
                    placeholder="e.g. GreenLeaf Café"
                    className="form-input"
                  />
                </Field>

                {/* Industry */}
                <Field id="industry" label="Industry / Business Type" required error={errors?.industry}>
                  <input
                    id="field-industry"
                    value={form?.industry ?? ''}
                    onChange={(e: any) => onChange('industry', e?.target?.value ?? '')}
                    placeholder="e.g. Restaurant, SaaS, E-commerce"
                    className="form-input"
                  />
                </Field>

                {/* Description */}
                <Field id="description" label="Business Description" required error={errors?.description}>
                  <textarea
                    id="field-description"
                    value={form?.description ?? ''}
                    onChange={(e: any) => onChange('description', e?.target?.value ?? '')}
                    placeholder="Briefly describe what your business does, its unique value, and what makes it special."
                    rows={3}
                    className="form-input resize-none"
                  />
                </Field>

                {/* Target Audience */}
                <Field id="targetAudience" label="Target Audience" required error={errors?.targetAudience}>
                  <input
                    id="field-targetAudience"
                    value={form?.targetAudience ?? ''}
                    onChange={(e: any) => onChange('targetAudience', e?.target?.value ?? '')}
                    placeholder="e.g. Health-conscious millennials, B2B SaaS buyers"
                    className="form-input"
                  />
                </Field>

                {/* Products/Services */}
                <Field id="productsServices" label="Products / Services Offered" required error={errors?.productsServices}>
                  <textarea
                    id="field-productsServices"
                    value={form?.productsServices ?? ''}
                    onChange={(e: any) => onChange('productsServices', e?.target?.value ?? '')}
                    placeholder="List your main products or services"
                    rows={2}
                    className="form-input resize-none"
                  />
                </Field>

                {/* Tone */}
                <Field id="tone" label="Writing Tone" required error={errors?.tone}>
                  <select
                    id="field-tone"
                    value={form?.tone ?? 'Professional'}
                    onChange={(e: any) => onChange('tone', e?.target?.value ?? 'Professional')}
                    className="form-input"
                  >
                    {TONES.map((t) => (
                      <option key={t} value={t}>{t}</option>
                    ))}
                  </select>
                </Field>

                {/* SEO Keywords */}
                <Field id="seoKeywords" label="Primary SEO Keywords" error={undefined}>
                  <input
                    id="field-seoKeywords"
                    value={form?.seoKeywords ?? ''}
                    onChange={(e: any) => onChange('seoKeywords', e?.target?.value ?? '')}
                    placeholder="e.g. organic restaurant, farm-to-table (comma separated)"
                    className="form-input"
                  />
                </Field>

                {/* CTA */}
                <Field id="callToAction" label="Call to Action Text" error={undefined}>
                  <input
                    id="field-callToAction"
                    value={form?.callToAction ?? ''}
                    onChange={(e: any) => onChange('callToAction', e?.target?.value ?? '')}
                    placeholder='e.g. "Book a Free Consultation"'
                    className="form-input"
                  />
                </Field>
              </div>

              <button
                onClick={handleGenerate}
                disabled={loading}
                className="btn-gradient w-full mt-8 py-4 rounded-xl text-base font-semibold text-white flex items-center justify-center gap-2 disabled:opacity-60 disabled:cursor-not-allowed"
              >
                {loading ? (
                  <>
                    <RefreshCw className="w-4 h-4 animate-spin" /> Generating...
                  </>
                ) : (
                  <>
                    <Sparkles className="w-4 h-4" /> Generate My Website Copy
                  </>
                )}
              </button>
            </div>
          </motion.div>
        </div>
      </section>

      {/* ===== LOADING STATE ===== */}
      <AnimatePresence>
        {loading && (
          <motion.section
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="py-16 px-4"
          >
            <div className="max-w-[600px] mx-auto text-center">
              <div className="gradient-spinner mx-auto mb-6" />
              <p className="text-lg text-violet-300 font-medium animate-pulse">{loadingMsg || 'AI is crafting your copy...'}</p>
              <div className="mt-8 space-y-3">
                {['Analyzing business...', 'Writing Home Page...', 'Writing About Page...', 'Building Services...', 'Generating FAQs...', 'Optimizing SEO...'].map(
                  (s, i) => (
                    <div key={i} className="flex items-center gap-3">
                      <div
                        className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-all ${
                          i <= loadingStep ? 'border-violet-500 bg-violet-500/20' : 'border-white/10'
                        }`}
                      >
                        {i < loadingStep && <Check className="w-3 h-3 text-violet-400" />}
                        {i === loadingStep && <div className="w-2 h-2 rounded-full bg-violet-400 animate-pulse" />}
                      </div>
                      <span className={`text-sm ${i <= loadingStep ? 'text-gray-300' : 'text-gray-600'}`}>{s}</span>
                    </div>
                  )
                )}
              </div>
              {/* Skeleton */}
              <div className="mt-10 space-y-4">
                <div className="shimmer h-6 w-3/4 mx-auto rounded" />
                <div className="shimmer h-4 w-full rounded" />
                <div className="shimmer h-4 w-5/6 mx-auto rounded" />
                <div className="shimmer h-4 w-2/3 mx-auto rounded" />
              </div>
            </div>
          </motion.section>
        )}
      </AnimatePresence>

      {/* ===== RESULTS ===== */}
      <AnimatePresence>
        {result && !loading && (
          <motion.section
            ref={resultsRef}
            initial={{ opacity: 0, y: 40 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.6 }}
            id="results"
            className="py-20 px-4"
          >
            <div className="max-w-[900px] mx-auto">
              <div className="text-center mb-10">
                <h2 className="text-3xl font-bold text-white">Your <span className="gradient-text">Generated Copy</span></h2>
                <p className="text-gray-400 mt-2">Click any tab to view and copy your content.</p>
              </div>

              {/* Tabs */}
              <div className="flex flex-wrap justify-center gap-2 mb-8">
                {TABS.map((t) => (
                  <button
                    key={t.id}
                    onClick={() => setActiveTab(t.id)}
                    className={`flex items-center gap-2 px-5 py-2.5 rounded-full text-sm font-medium transition-all ${
                      activeTab === t.id
                        ? 'bg-violet-600/20 text-violet-300 glow-primary tab-active'
                        : 'text-gray-400 hover:text-white hover:bg-white/5'
                    }`}
                  >
                    <t.icon className="w-4 h-4" /> {t.label}
                  </button>
                ))}
              </div>

              {/* Tab content card */}
              <div className="glass-strong rounded-2xl p-6 sm:p-8 min-h-[300px]">
                {/* Action bar */}
                <div className="flex flex-wrap gap-3 mb-6">
                  <button
                    onClick={() => copyText(tabToText(activeTab), activeTab)}
                    className="flex items-center gap-1.5 text-xs bg-white/5 hover:bg-white/10 text-gray-300 px-3 py-1.5 rounded-lg transition-all"
                  >
                    {copied === activeTab ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3" />}
                    {copied === activeTab ? 'Copied!' : 'Copy Section'}
                  </button>
                  <button
                    onClick={() => setEditing(!editing)}
                    className="flex items-center gap-1.5 text-xs bg-white/5 hover:bg-white/10 text-gray-300 px-3 py-1.5 rounded-lg transition-all"
                  >
                    <Pencil className="w-3 h-3" /> {editing ? 'Lock Edit' : 'Edit'}
                  </button>
                  <button
                    onClick={copyAll}
                    className="flex items-center gap-1.5 text-xs bg-white/5 hover:bg-white/10 text-gray-300 px-3 py-1.5 rounded-lg transition-all"
                  >
                    {copied === 'all' ? <Check className="w-3 h-3 text-green-400" /> : <Copy className="w-3 h-3" />}
                    {copied === 'all' ? 'All Copied!' : 'Copy All'}
                  </button>
                  <button
                    onClick={downloadTxt}
                    className="flex items-center gap-1.5 text-xs bg-white/5 hover:bg-white/10 text-gray-300 px-3 py-1.5 rounded-lg transition-all"
                  >
                    <Download className="w-3 h-3" /> Download TXT
                  </button>
                  <button
                    onClick={handleGenerateAgain}
                    className="flex items-center gap-1.5 text-xs bg-violet-600/20 hover:bg-violet-600/30 text-violet-300 px-3 py-1.5 rounded-lg transition-all ml-auto"
                  >
                    <RefreshCw className="w-3 h-3" /> Generate Again
                  </button>
                </div>

                {/* Content */}
                <AnimatePresence mode="wait">
                  <motion.div
                    key={activeTab}
                    initial={{ opacity: 0, x: 20 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, x: -20 }}
                    transition={{ duration: 0.25 }}
                  >
                    {activeTab === 'home' && <HomeTab data={result?.homePage} editable={editing} />}
                    {activeTab === 'about' && <AboutTab data={result?.aboutPage} editable={editing} />}
                    {activeTab === 'services' && <ServicesTab data={result?.servicesPage} editable={editing} />}
                    {activeTab === 'faqs' && <FaqsTab data={result?.faqs} openFaq={openFaq} setOpenFaq={setOpenFaq} />}
                    {activeTab === 'seo' && <SeoTab data={result?.seoMetadata} editable={editing} />}
                  </motion.div>
                </AnimatePresence>
              </div>
            </div>
          </motion.section>
        )}
      </AnimatePresence>

      {/* ===== FOOTER ===== */}
      <footer className="border-t border-white/5 py-10 px-4">
        <div className="max-w-[1200px] mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-md bg-gradient-to-br from-violet-500 to-indigo-600 flex items-center justify-center">
              <Zap className="w-3 h-3 text-white" />
            </div>
            <span className="text-sm font-semibold gradient-text">CopyForge AI</span>
          </div>
          <p className="text-xs text-gray-500">Built with ❤️ and AI · © 2026 CopyForge AI</p>
        </div>
      </footer>
    </div>
  );
}

/* ─────────── SUB-COMPONENTS ─────────── */

function Field({ id, label, required, error, children }: { id: string; label: string; required?: boolean; error?: string; children: React.ReactNode }) {
  return (
    <div>
      <label htmlFor={`field-${id}`} className="block text-sm font-medium text-gray-300 mb-1.5">
        {label} {required && <span className="text-violet-400">*</span>}
      </label>

      {children}
      {error && <p className="mt-1 text-xs text-red-400">{error}</p>}
    </div>
  );
}

function SectionLabel({ text }: { text: string }) {
  return <h4 className="text-xs uppercase tracking-widest text-violet-400/80 font-semibold mb-2 mt-6 first:mt-0">{text}</h4>;
}

function HomeTab({ data, editable }: { data?: HomePageContent; editable: boolean }) {
  return (
    <div>
      <h3 className="text-2xl font-bold text-white mb-1" contentEditable={editable} suppressContentEditableWarning>{data?.headline ?? ''}</h3>
      <p className="text-violet-300 text-sm mb-4" contentEditable={editable} suppressContentEditableWarning>{data?.subheadline ?? ''}</p>
      <SectionLabel text="Introduction" />
      <p className="text-gray-300 text-sm leading-relaxed" contentEditable={editable} suppressContentEditableWarning>{data?.introduction ?? ''}</p>
      <SectionLabel text="Value Propositions" />
      <ul className="space-y-2">
        {(data?.valuePropositions ?? []).map((v: string, i: number) => (
          <li key={i} className="flex items-start gap-2 text-sm text-gray-300">
            <Target className="w-4 h-4 text-violet-400 mt-0.5 flex-shrink-0" />
            <span contentEditable={editable} suppressContentEditableWarning>{v ?? ''}</span>
          </li>
        ))}
      </ul>
      <SectionLabel text="Call to Action" />
      <div className="inline-block btn-gradient px-5 py-2 rounded-lg text-sm font-semibold text-white" contentEditable={editable} suppressContentEditableWarning>
        {data?.callToAction ?? ''}
      </div>
    </div>
  );
}

function AboutTab({ data, editable }: { data?: AboutPageContent; editable: boolean }) {
  return (
    <div>
      <SectionLabel text="Introduction" />
      <p className="text-gray-300 text-sm leading-relaxed" contentEditable={editable} suppressContentEditableWarning>{data?.introduction ?? ''}</p>
      <SectionLabel text="Mission" />
      <p className="text-gray-300 text-sm leading-relaxed" contentEditable={editable} suppressContentEditableWarning>{data?.mission ?? ''}</p>
      <SectionLabel text="Values" />
      <p className="text-gray-300 text-sm leading-relaxed" contentEditable={editable} suppressContentEditableWarning>{data?.values ?? ''}</p>
      <SectionLabel text="What Makes Us Different" />
      <p className="text-gray-300 text-sm leading-relaxed" contentEditable={editable} suppressContentEditableWarning>{data?.whatMakesUsDifferent ?? ''}</p>
    </div>
  );
}

function ServicesTab({ data, editable }: { data?: ServicesPageContent; editable: boolean }) {
  return (
    <div>
      <p className="text-gray-300 text-sm leading-relaxed mb-6" contentEditable={editable} suppressContentEditableWarning>{data?.intro ?? ''}</p>
      <div className="space-y-4">
        {(data?.services ?? []).map((svc: Service, i: number) => (
          <div key={i} className="glass rounded-xl p-5">
            <h4 className="text-base font-semibold text-white mb-2" contentEditable={editable} suppressContentEditableWarning>{svc?.name ?? ''}</h4>
            <p className="text-gray-400 text-sm mb-3" contentEditable={editable} suppressContentEditableWarning>{svc?.description ?? ''}</p>
            <ul className="space-y-1 mb-3">
              {(svc?.benefits ?? []).map((b: string, j: number) => (
                <li key={j} className="text-sm text-gray-300 flex items-center gap-2">
                  <Check className="w-3.5 h-3.5 text-green-400" />
                  <span contentEditable={editable} suppressContentEditableWarning>{b ?? ''}</span>
                </li>
              ))}
            </ul>
            <span className="text-xs text-violet-400 font-medium" contentEditable={editable} suppressContentEditableWarning>{svc?.callToAction ?? ''}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

function FaqsTab({ data, openFaq, setOpenFaq }: { data?: FAQ[]; openFaq: number | null; setOpenFaq: (v: number | null) => void }) {
  return (
    <div className="space-y-3">
      {(data ?? []).map((faq: FAQ, i: number) => (
        <div key={i} className="glass rounded-xl overflow-hidden">
          <button
            onClick={() => setOpenFaq(openFaq === i ? null : i)}
            className="w-full flex items-center justify-between p-4 text-left"
          >
            <span className="text-sm font-medium text-white pr-4">{faq?.question ?? ''}</span>
            {openFaq === i ? <ChevronUp className="w-4 h-4 text-violet-400 flex-shrink-0" /> : <ChevronDown className="w-4 h-4 text-gray-500 flex-shrink-0" />}
          </button>
          <div className={`faq-answer px-4 pb-4 ${openFaq === i ? 'open' : ''}`}>
            <p className="text-sm text-gray-400 leading-relaxed">{faq?.answer ?? ''}</p>
          </div>
        </div>
      ))}
    </div>
  );
}

function SeoTab({ data, editable }: { data?: SEOContent; editable: boolean }) {
  return (
    <div className="space-y-4">
      <div>
        <SectionLabel text="SEO Title" />
        <p className="text-gray-300 text-sm" contentEditable={editable} suppressContentEditableWarning>{data?.seoTitle ?? ''}</p>
      </div>
      <div>
        <SectionLabel text="Meta Description" />
        <p className="text-gray-300 text-sm" contentEditable={editable} suppressContentEditableWarning>{data?.metaDescription ?? ''}</p>
      </div>
      <div>
        <SectionLabel text="Primary Keyword" />
        <span className="inline-block bg-violet-600/20 text-violet-300 text-xs px-3 py-1 rounded-full">{data?.primaryKeyword ?? ''}</span>
      </div>
      <div>
        <SectionLabel text="Secondary Keywords" />
        <div className="flex flex-wrap gap-2">
          {(data?.secondaryKeywords ?? []).map((kw: string, i: number) => (
            <span key={i} className="inline-block bg-white/5 text-gray-300 text-xs px-3 py-1 rounded-full">{kw ?? ''}</span>
          ))}
        </div>
      </div>
      <div>
        <SectionLabel text="URL Slug" />
        <code className="block bg-black/30 text-green-400 text-sm px-4 py-2 rounded-lg font-mono">/{data?.urlSlug ?? ''}</code>
      </div>
    </div>
  );
}
