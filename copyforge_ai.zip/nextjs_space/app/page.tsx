import CopyForgeApp from './components/copy-forge-app';

export default function Home() {
  return <CopyForgeApp />;
}
