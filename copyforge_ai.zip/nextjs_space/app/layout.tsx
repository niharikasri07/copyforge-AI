import type { Metadata } from 'next';
import './globals.css';

export const dynamic = 'force-dynamic';

export async function generateMetadata(): Promise<Metadata> {
  const base = process.env.NEXTAUTH_URL || 'http://localhost:3000';
  return {
    title: 'CopyForge AI — AI-Powered Website Copy Generator',
    description: 'Stop staring at a blank page. Tell us about your business and our AI writes compelling, SEO-optimized website copy for every page — instantly.',
    metadataBase: new URL(base),
    icons: {
      icon: '/favicon.svg',
      shortcut: '/favicon.svg',
    },
    openGraph: {
      title: 'CopyForge AI — AI-Powered Website Copy Generator',
      description: 'Generate stunning website copy in seconds with AI.',
      images: [{ url: '/og-image.png', width: 1200, height: 630 }],
    },
  };
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" className="dark scroll-smooth">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <script src="https://apps.abacus.ai/chatllm/appllm-lib.js" />
      </head>
      <body className="min-h-screen bg-[#0a0f1e] text-white antialiased">
        {children}
      </body>
    </html>
  );
}
