import { NextRequest } from 'next/server';

export const dynamic = 'force-dynamic';

const DEMO_RESULT = {
  homePage: {
    headline: 'Farm-Fresh Flavors, Served with Soul',
    subheadline: 'GreenLeaf Café — Where Every Bite Tells a Story of Sustainability',
    introduction:
      'Welcome to GreenLeaf Café, a neighborhood gathering spot where locally-sourced ingredients meet globally-inspired recipes. We believe great food starts with great farms and ends with a smile across the table.',
    valuePropositions: [
      '100% organic, locally-sourced ingredients from farms within 50 miles',
      'Seasonal menus that celebrate the freshest produce available',
      'A warm, inviting atmosphere designed for community connection',
    ],
    callToAction: 'Reserve Your Table Today',
  },
  aboutPage: {
    introduction:
      'GreenLeaf Café was born from a simple idea: food should nourish both body and community. Founded in 2019 by chef Maya Torres, we have grown from a weekend pop-up to one of the city\'s most beloved dining destinations.',
    mission:
      'Our mission is to redefine casual dining by proving that sustainable, organic food can be accessible, delicious, and affordable for everyone.',
    values:
      'Sustainability drives every decision we make — from compostable packaging to solar-powered kitchens. We pay fair wages, partner with local farmers, and donate 5% of profits to urban gardening programs.',
    whatMakesUsDifferent:
      'Unlike typical restaurants, we publish the name and location of every farm behind each dish. Full transparency, zero greenwashing. Our chef-driven menu rotates weekly to match what\'s actually in season — no frozen shortcuts.',
  },
  servicesPage: {
    intro:
      'From weekday lunches to catered events, GreenLeaf Café offers experiences crafted around fresh, seasonal food.',
    services: [
      {
        name: 'Dine-In Experience',
        description:
          'Enjoy our full seasonal menu in a sunlit, plant-filled space designed for relaxation and connection.',
        benefits: [
          'Weekly rotating chef specials',
          'Dedicated vegan and gluten-free options',
        ],
        callToAction: 'View Today\'s Menu',
      },
      {
        name: 'Catering & Events',
        description:
          'Let us bring the GreenLeaf experience to your office, wedding, or celebration with fully customized menus.',
        benefits: [
          'Bespoke menus for groups of 20-200',
          'Eco-friendly, zero-waste event packages',
        ],
        callToAction: 'Request a Catering Quote',
      },
      {
        name: 'Farm Box Subscriptions',
        description:
          'Get a curated weekly box of seasonal produce, house-made sauces, and recipes delivered to your door.',
        benefits: [
          'Skip or cancel anytime',
          'Includes exclusive recipes from Chef Maya',
        ],
        callToAction: 'Subscribe Now',
      },
    ],
  },
  faqs: [
    {
      question: 'Do you accommodate dietary restrictions?',
      answer:
        'Absolutely. Every menu item is labeled for common allergens, and we offer extensive vegan, vegetarian, and gluten-free options. Just let your server know about any specific needs.',
    },
    {
      question: 'Where do you source your ingredients?',
      answer:
        'We partner with 12 local farms within a 50-mile radius. Each dish on our menu lists its source farms so you know exactly where your food comes from.',
    },
    {
      question: 'Can I book GreenLeaf for a private event?',
      answer:
        'Yes! We host private events for up to 60 guests in our garden room. Contact our events team for availability and custom menu options.',
    },
    {
      question: 'Do you offer takeout or delivery?',
      answer:
        'We offer takeout daily. Delivery is available through our Farm Box Subscription program, which brings curated ingredients and meals to your door each week.',
    },
    {
      question: 'Is there parking available?',
      answer:
        'We have a dedicated parking lot behind the café with 30 spaces, plus street parking is available on both sides of Maple Avenue.',
    },
  ],
  seoMetadata: {
    seoTitle: 'GreenLeaf Café — Farm-to-Table Organic Restaurant',
    metaDescription:
      'GreenLeaf Café serves farm-fresh, organic meals from locally-sourced ingredients. Dine in, cater your events, or subscribe to our weekly Farm Box. Reserve your table today.',
    primaryKeyword: 'organic restaurant',
    secondaryKeywords: ['farm-to-table dining', 'sustainable café', 'local organic food'],
    urlSlug: 'greenleaf-cafe',
  },
};

function buildPrompt(data: any): string {
  return `You are an expert website copywriter and conversion specialist. Generate compelling, professional website copy for the following business.

Business Details:
- Business Name: ${data?.businessName ?? 'Unknown'}
- Industry: ${data?.industry ?? 'General'}
- Description: ${data?.description ?? ''}
- Target Audience: ${data?.targetAudience ?? 'General public'}
- Products/Services: ${data?.productsServices ?? ''}
- Tone: ${data?.tone ?? 'Professional'}
- SEO Keywords: ${data?.seoKeywords ?? ''}
- Call to Action: ${data?.callToAction ?? 'Get Started'}

Generate website copy for ALL 5 sections below. Be specific to this business — use the brand name, reference their actual services, and write in the requested tone.

Respond with raw JSON only. Do not include code blocks, markdown, or any other formatting.

{
  "homePage": {
    "headline": "A catchy, compelling headline (6-12 words)",
    "subheadline": "A supporting line that adds context",
    "introduction": "2-3 engaging sentences introducing the business",
    "valuePropositions": ["Benefit 1", "Benefit 2", "Benefit 3"],
    "callToAction": "Action-oriented CTA button text"
  },
  "aboutPage": {
    "introduction": "2-3 sentences about who they are",
    "mission": "A clear mission statement (1-2 sentences)",
    "values": "What the company values and stands for (2-3 sentences)",
    "whatMakesUsDifferent": "Key differentiators (2-3 sentences)"
  },
  "servicesPage": {
    "intro": "Brief intro to services offered",
    "services": [
      {
        "name": "Service name",
        "description": "What this service is (2-3 sentences)",
        "benefits": ["Benefit 1", "Benefit 2"],
        "callToAction": "CTA for this service"
      }
    ]
  },
  "faqs": [
    {
      "question": "A realistic FAQ question",
      "answer": "A helpful, detailed answer (2-3 sentences)"
    }
  ],
  "seoMetadata": {
    "seoTitle": "SEO-optimized page title (50-60 chars)",
    "metaDescription": "Meta description (150-160 chars)",
    "primaryKeyword": "main keyword",
    "secondaryKeywords": ["keyword 2", "keyword 3"],
    "urlSlug": "url-friendly-slug"
  }
}

Generate at least 3 services and 5 FAQs. Make the copy sound human, not robotic. Use persuasive language that connects emotionally with the target audience.`;
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    const requiredFields = ['businessName', 'industry', 'description', 'targetAudience', 'productsServices', 'tone'];
    for (const field of requiredFields) {
      if (!body?.[field]?.trim?.()) {
        return new Response(
          JSON.stringify({ status: 'error', message: `Missing required field: ${field}` }),
          { status: 400, headers: { 'Content-Type': 'application/json' } }
        );
      }
    }

    const apiKey = process.env.ABACUSAI_API_KEY;
    if (!apiKey) {
      // Return demo data if no key
      const stream = new ReadableStream({
        start(controller) {
          const encoder = new TextEncoder();
          controller.enqueue(encoder.encode(`data: ${JSON.stringify({ status: 'processing', message: 'Generating (demo mode)...' })}\n\n`));
          controller.enqueue(encoder.encode(`data: ${JSON.stringify({ status: 'completed', result: DEMO_RESULT })}\n\n`));
          controller.enqueue(encoder.encode('data: [DONE]\n\n'));
          controller.close();
        },
      });
      return new Response(stream, { headers: streamHeaders() });
    }

    const prompt = buildPrompt(body);

    const response = await fetch('https://apps.abacus.ai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: 'gpt-5.4-mini',
        messages: [
          { role: 'system', content: 'You are a professional website copywriter. Always respond with valid JSON only.' },
          { role: 'user', content: prompt },
        ],
        stream: true,
        max_tokens: 4000,
        temperature: 0.7,
        response_format: { type: 'json_object' },
      }),
    });

    if (!response.ok) {
      console.error('LLM API error:', response.status, response.statusText);
      return demoFallbackStream('AI service temporarily unavailable. Showing demo content.');
    }

    let buffer = '';
    let partialRead = '';
    const reader = response.body?.getReader();
    const decoder = new TextDecoder();

    const stream = new ReadableStream({
      async start(controller) {
        const encoder = new TextEncoder();
        const steps = [
          'Analyzing your business...',
          'Crafting your Home Page copy...',
          'Writing About Page...',
          'Building Services section...',
          'Generating FAQs...',
          'Optimizing SEO metadata...',
        ];
        let stepIdx = 0;
        let chunkCount = 0;

        try {
          if (!reader) throw new Error('No response body');

          while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            partialRead += decoder.decode(value, { stream: true });
            const lines = partialRead.split('\n');
            partialRead = lines.pop() ?? '';

            for (const line of lines) {
              if (line.startsWith('data: ')) {
                const data = line.slice(6);
                if (data === '[DONE]') {
                  let finalResult: any;
                  try {
                    finalResult = JSON.parse(buffer);
                  } catch {
                    finalResult = DEMO_RESULT;
                  }
                  controller.enqueue(
                    encoder.encode(`data: ${JSON.stringify({ status: 'completed', result: finalResult })}\n\n`)
                  );
                  controller.enqueue(encoder.encode('data: [DONE]\n\n'));
                  controller.close();
                  return;
                }
                try {
                  const parsed = JSON.parse(data);
                  const delta = parsed?.choices?.[0]?.delta?.content ?? '';
                  buffer += delta;
                  chunkCount++;

                  if (chunkCount % 8 === 0 || stepIdx < steps.length) {
                    const msg = stepIdx < steps.length ? steps[stepIdx] ?? 'Generating...' : 'Polishing your copy...';
                    if (chunkCount % 15 === 0 && stepIdx < steps.length) stepIdx++;
                    controller.enqueue(
                      encoder.encode(`data: ${JSON.stringify({ status: 'processing', message: msg, step: stepIdx })}\n\n`)
                    );
                  }
                } catch {
                  // skip invalid
                }
              }
            }
          }

          // If we exited loop without [DONE]
          let finalResult: any;
          try {
            finalResult = JSON.parse(buffer);
          } catch {
            finalResult = DEMO_RESULT;
          }
          controller.enqueue(
            encoder.encode(`data: ${JSON.stringify({ status: 'completed', result: finalResult })}\n\n`)
          );
          controller.enqueue(encoder.encode('data: [DONE]\n\n'));
          controller.close();
        } catch (error: any) {
          console.error('Stream error:', error);
          controller.enqueue(
            encoder.encode(`data: ${JSON.stringify({ status: 'completed', result: DEMO_RESULT })}\n\n`)
          );
          controller.enqueue(encoder.encode('data: [DONE]\n\n'));
          controller.close();
        }
      },
    });

    return new Response(stream, { headers: streamHeaders() });
  } catch (error: any) {
    console.error('Generate error:', error);
    return demoFallbackStream('An unexpected error occurred. Showing demo content.');
  }
}

function streamHeaders() {
  return {
    'Content-Type': 'text/event-stream',
    'Cache-Control': 'no-cache',
    Connection: 'keep-alive',
  };
}

function demoFallbackStream(msg: string) {
  const stream = new ReadableStream({
    start(controller) {
      const encoder = new TextEncoder();
      controller.enqueue(encoder.encode(`data: ${JSON.stringify({ status: 'processing', message: msg })}\n\n`));
      controller.enqueue(encoder.encode(`data: ${JSON.stringify({ status: 'completed', result: DEMO_RESULT })}\n\n`));
      controller.enqueue(encoder.encode('data: [DONE]\n\n'));
      controller.close();
    },
  });
  return new Response(stream, { headers: streamHeaders() });
}
